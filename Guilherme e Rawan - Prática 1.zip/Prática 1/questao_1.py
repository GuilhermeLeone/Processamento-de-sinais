import numpy as np
import matplotlib.pyplot as plt
from IPython.display import Audio

fs = 44100
duration = 5
t = np.linspace(0, duration, int(fs * duration), endpoint=False)
frequencies = [500, 5000, 10000]

for f in frequencies:
    x = np.cos(2 * np.pi * f * t)
    plt.plot(t[:1000], x[:1000])
    plt.title(f'Frequência {f} Hz')
    plt.show()
