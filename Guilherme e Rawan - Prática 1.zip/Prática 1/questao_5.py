from scipy.io import wavfile
import matplotlib.pyplot as plt

fs_h, h = wavfile.read('h_banheiro.wav')
fs_t, taca = wavfile.read('sinal_taca.wav')
plt.subplot(2,1,1); plt.plot(h)
plt.subplot(2,1,2); plt.plot(taca)
plt.show()
