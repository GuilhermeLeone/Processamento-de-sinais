from scipy.io import wavfile
import matplotlib.pyplot as plt

fs, data = wavfile.read('handel.wav')
plt.plot(data)
plt.title('Sinal Handel')
plt.show()
