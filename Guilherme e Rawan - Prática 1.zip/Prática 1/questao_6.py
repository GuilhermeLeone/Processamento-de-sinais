import numpy as np
from scipy.io import wavfile
from scipy.signal import resample

fs_h, h = wavfile.read('h_banheiro.wav')
fs_a, audio = wavfile.read('handel.wav')
# Reamostragem e Convolução
audio_res = resample(audio, int(len(audio) * fs_h / fs_a))
resultado = np.convolve(audio_res, h, mode='full')
wavfile.write('resultado_reverberado.wav', fs_h, resultado.astype(np.float32))
