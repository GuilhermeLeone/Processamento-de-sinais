import numpy as np
from scipy.signal import chirp
import matplotlib.pyplot as plt

fs = 44100
duration = 5
t = np.linspace(0, duration, int(fs * duration), endpoint=False)
methods = ['linear', 'quadratic', 'logarithmic']
for m in methods:
    s = chirp(t, f0=500, f1=10000, t1=duration, method=m)
    plt.specgram(s, Fs=fs)
    plt.title(f'Chirp {m}')
    plt.show()
